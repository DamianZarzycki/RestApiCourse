package com.applicationweb.app.ws.exceptions;

public class CouldNotCreateRecordException extends RuntimeException {


    private static final long serialVersionUID = -7045623563241642284L;

    public CouldNotCreateRecordException(String message){
        super(message);
    }
}
