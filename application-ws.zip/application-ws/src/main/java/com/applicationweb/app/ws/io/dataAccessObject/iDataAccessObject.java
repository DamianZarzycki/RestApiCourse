package com.applicationweb.app.ws.io.dataAccessObject;

import com.applicationweb.app.ws.shared.dto.UserDTO;

public interface iDataAccessObject {
    // IMPORTANT: Always create at the begining methods to 'open' database and to 'close' it before any other methods

    void openConnection();
    UserDTO getUserByUserName(String userName);
    UserDTO saveUser(UserDTO user);
    void closeConnection();
}
