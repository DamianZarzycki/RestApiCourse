package com.applicationweb.app.ws.service.impl;

import com.applicationweb.app.ws.exceptions.CouldNotCreateRecordException;
import com.applicationweb.app.ws.io.dataAccessObject.iDataAccessObject;
import com.applicationweb.app.ws.io.dataAccessObject.impl.MySQLdatabaseAccessObject;
import com.applicationweb.app.ws.service.iUsersService;
import com.applicationweb.app.ws.shared.dto.UserDTO;
import com.applicationweb.app.ws.ui.model.response.ErrorMessages;
import com.applicationweb.app.ws.utils.UserProfileUtils;


public class UsersServiceImpl implements iUsersService {

    iDataAccessObject database;

    public UsersServiceImpl() {
        this.database = new MySQLdatabaseAccessObject();
    }

    UserProfileUtils userProfileUtils = new UserProfileUtils();

    @Override
    public UserDTO createUser(UserDTO user) {
        UserDTO returnValue = null;

        // Validate the required fields
        userProfileUtils.validateRequiredFields(user);

        // Check if user already exists
        UserDTO existingUser = this.getUserByUserName(user.getEmail());
        if (existingUser != null) {
            throw new CouldNotCreateRecordException(ErrorMessages.RECORD_ALREADY_EXISTS.name());
        }

        // Generate secure public user id
        String userId = userProfileUtils.generateUserId(30);
        user.setUserId(userId);

        // Generate salt
        String salt = userProfileUtils.getSalt(30);

        // Generate secure password
        String encryptedPassword = userProfileUtils.generateSecurePassword(user.getPassword(), salt);
        user.setSalt(salt);
        user.setEncryptedPassword(encryptedPassword);

        // Record data into database
        returnValue = this.saveUser(user);


        // Return back the user profile
        return returnValue;
    }

    private UserDTO getUserByUserName(String userName) {
        UserDTO userDTO = null;

        if (userName == null || userName.isEmpty()) {
            return null;
        }

        // Connect to database
        try {
            this.database.openConnection();
            userDTO = this.database.getUserByUserName(userName);
        } finally {
            this.database.closeConnection();
        }
        return userDTO;
    }

    private UserDTO saveUser(UserDTO user) {
        UserDTO returnValue = null;
        // Connect to database
        try {
            this.database.openConnection();
            returnValue = this.database.saveUser(user);
        } finally {
            this.database.closeConnection();
        }
        return returnValue;
    }
}
