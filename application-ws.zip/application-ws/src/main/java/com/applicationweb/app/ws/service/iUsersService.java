package com.applicationweb.app.ws.service;

import com.applicationweb.app.ws.shared.dto.UserDTO;

public interface iUsersService {
    public UserDTO createUser(UserDTO user);
}
