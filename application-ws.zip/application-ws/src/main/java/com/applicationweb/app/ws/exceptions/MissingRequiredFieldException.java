package com.applicationweb.app.ws.exceptions;

public class MissingRequiredFieldException extends RuntimeException {

    private static final long serialVersionUID = -9004909459245897936L;

    public MissingRequiredFieldException(String message){
        super(message);
    }
}
