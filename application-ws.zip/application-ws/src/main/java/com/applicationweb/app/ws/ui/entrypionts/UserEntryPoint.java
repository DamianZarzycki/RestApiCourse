package com.applicationweb.app.ws.ui.entrypionts;

import com.applicationweb.app.ws.service.iUsersService;
import com.applicationweb.app.ws.service.impl.UsersServiceImpl;
import com.applicationweb.app.ws.shared.dto.UserDTO;
import com.applicationweb.app.ws.ui.model.request.CreateUserRequestModel;
import com.applicationweb.app.ws.ui.model.response.UserProfileRest;
import org.springframework.beans.BeanUtils;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;



@Path("/users")
public class UserEntryPoint {

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public UserProfileRest createUser(CreateUserRequestModel requestObject){
        System.out.print("I am in POST");
        UserProfileRest returnValue = new UserProfileRest();

        // Prepare UserDTO
        UserDTO userDTO = new UserDTO();
        BeanUtils.copyProperties(requestObject,userDTO);

        // Create new user
        iUsersService userService = new UsersServiceImpl();
        UserDTO createdUserProfile = userService.createUser(userDTO);

        // Prepare response
        BeanUtils.copyProperties(createdUserProfile, returnValue);


        return returnValue;

    }

}
